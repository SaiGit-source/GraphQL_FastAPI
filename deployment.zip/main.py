import json
import logging
import strawberry
from fastapi import FastAPI
from strawberry.fastapi import GraphQLRouter
from mangum import Mangum
from type.user import Query, Mutation

logger = logging.getLogger()
logger.setLevel(logging.INFO)

schema = strawberry.Schema(query=Query, mutation=Mutation)
graphql_router = GraphQLRouter(schema)

app = FastAPI()
app.include_router(graphql_router, prefix="/graphql")

_mangum = Mangum(app, lifespan="off", api_gateway_base_path="/GraphQL-FastAPI")

def handler(event, context):
    logger.info("EVENT: %s", json.dumps(event, default=str))
    if "httpMethod" in event and "version" not in event:
        event["version"] = "1.0"
    try:
        response = _mangum(event, context)
    except Exception as e:
        logger.error("Mangum error: %s | Event keys: %s", str(e), list(event.keys()))
        raise
    logger.info("RESPONSE status: %s", response.get("statusCode"))
    return response

