from fastapi import APIRouter
import strawberry
from conn.db import get_db
from models.user import UserModel
from type.user import Mutation, Query
from type.user import UserType
from strawberry.fastapi import GraphQLRouter

user = APIRouter()
schema = strawberry.Schema(query=Query, mutation=Mutation)
graphql_app = GraphQLRouter(schema)
user.include_router(graphql_app, prefix="/graphql")

